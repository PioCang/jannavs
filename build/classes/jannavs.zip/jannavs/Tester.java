package jannavs;

import java.io.File;
import java.io.IOException;


public class Tester
{
     private static int[][] feedSamples, referenceSamples;
     private static final String sourceFilename = "C:\\Users\\user\\Desktop\\FEED.wav";
     private static final String referenceFilename = "C:\\Users\\user\\Desktop\\REFER.wav";

     static double[][] oMINUSf, oMINUSr;

     public static void test()
     {
          JANNAVS.weights = new double[JANNAVS.numberOfNodes][JANNAVS.numberOfNodes];
          WeightsIO.retrieveWeights();
          JANNAVS.outputOfNode = new double[JANNAVS.numberOfNodes];
          int numberOfTestInputs = Tester.getInputSamples();
          double[][] outputSamples = new double[2][numberOfTestInputs];
          oMINUSf = new double[2][numberOfTestInputs];
          oMINUSr = new double[2][numberOfTestInputs];


          JANNAVS.outputOfNode = new double[JANNAVS.numberOfNodes];
          for (int i = 0 ; i < numberOfTestInputs; i++)
          {
               double l1, l2, r1, r2;
               l1 = l2 = r1 = r2 = 0;

               /*if (i > 1)
               {
                    l1 = feedSamples[0][i-2];
                    l2 = feedSamples[0][i-1];

                    r1 = feedSamples[1][i-2];
                    r2 = feedSamples[1][i-1];
               }*/


               JANNAVS.feedForward(feedSamples[0][i], feedSamples[1][i], l1, l2, r1, r2);

               outputSamples[0][i] = (i < 45) ? 0 : JANNAVS.outputOfNode[8];
               outputSamples[1][i] = (i < 45) ? 0 : JANNAVS.outputOfNode[9];

               oMINUSr[0][i] = JANNAVS.outputOfNode[8] - (referenceSamples[0][i] / Math.pow(2, 15));
               oMINUSr[1][i] = JANNAVS.outputOfNode[9] - (referenceSamples[1][i] / Math.pow(2, 15));

               oMINUSf[0][i] = JANNAVS.outputOfNode[8] - (feedSamples[0][i] / Math.pow(2, 15));
               oMINUSf[1][i] = JANNAVS.outputOfNode[9] - (feedSamples[1][i] / Math.pow(2, 15));

          }

          JANNAVS.tol = 9 * Math.pow(10, -1);
          int j = 0;
          int numberOfConverged = numberOfTestInputs;

          while(numberOfConverged >= 0.5 * numberOfTestInputs)
          {
               numberOfConverged = 0;

               for (int i = 0 ; i < numberOfTestInputs; i++)
               {
                    double oLeft = referenceSamples[0][i] / Math.pow(2, 15);
                    double oRight = referenceSamples[1][i] / Math.pow(2, 15);

                    double left_diff = Math.abs(oLeft - outputSamples[0][i]);
                    double right_diff = Math.abs(oRight - outputSamples[1][i]);

                    if (left_diff <= JANNAVS.tol && right_diff <= JANNAVS.tol)
                    {
                         numberOfConverged++;
                    }
               }

               j++;
               System.out.printf("%d\t%.10f\t%.4f\n", j, JANNAVS.tol, ((float) numberOfConverged/numberOfTestInputs));


               if (JANNAVS.tol >=  2 * Math.pow(10, -1))
               {
                    JANNAVS.tol -= Math.pow(10, -1);
               }
               else if (JANNAVS.tol >= 2  * Math.pow(10, -2))
               {
                    JANNAVS.tol -= Math.pow(10, -2);
               }
               else if (JANNAVS.tol >= 2  * Math.pow(10, -3))
               {
                    JANNAVS.tol -= Math.pow(10, -3);
               }
               else
               {
                    break;
               }

          }

          System.out.println("---TESTING END---");


          encodeOutputWave(outputSamples, "C:\\Users\\user\\Desktop\\OUTPUT.wav");
          cleanUp();
     }

     public static void cleanUp()
     {
          oMINUSf = null;
          oMINUSr = null;
          JANNAVS.weights = null;
          JANNAVS.outputOfNode = null;
     }


     private static int getInputSamples()
     {
          int numberOfTestInputs = 0;

          try
          {
               // Open the wav file specified as the first argument
               WavFile sourceWave = WavFile.openWavFile(new File(sourceFilename));
               WavFile referenceWave = WavFile.openWavFile(new File(referenceFilename));

/*HERE*/       numberOfTestInputs = (int) sourceWave.numFrames;
               feedSamples = new int[sourceWave.numChannels][(int) sourceWave.numFrames];
               referenceSamples = new int[sourceWave.numChannels][(int) sourceWave.numFrames];

               sourceWave.readFrames(feedSamples, (int) sourceWave.numFrames);
               referenceWave.readFrames(referenceSamples, (int) sourceWave.numFrames);

               // Close the wavFile
               sourceWave.close();
               referenceWave.close();
          }
          catch (IOException | WavFileException e)
          {
                  System.err.println(e);
          }

          return  numberOfTestInputs;
     }


     public static void encodeOutputWave(double[][] outputSamples, String outputWave)
     {
          String temp ="C:\\Users\\user\\Desktop\\oMINf.wav";
          String temp2 = "C:\\Users\\user\\Desktop\\oMINr.wav";
          try
          {
                  int sampleRate = 44100;

                  // Create a wav file with the name specified as the first argument
                  WavFile wavFile = WavFile.newWavFile(new File(outputWave), 2, outputSamples[0].length, 16, sampleRate);
                  wavFile.writeFrames(outputSamples, outputSamples[0].length);

                  WavFile otherFile = WavFile.newWavFile(new File(temp2), 2, oMINUSr[0].length, 16, sampleRate);
                  otherFile.writeFrames(oMINUSr, oMINUSr[0].length);

                  WavFile anotherFile = WavFile.newWavFile(new File(temp), 2, oMINUSf[0].length, 16, sampleRate);
                  anotherFile.writeFrames(oMINUSf, oMINUSf[0].length);

                  // Close the wavFile
                  wavFile.close();
                  otherFile.close();
                  anotherFile.close();

          }
          catch (IOException | WavFileException e)
          {
                  System.err.println(e);
          }
     }
}
